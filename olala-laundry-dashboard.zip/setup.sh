#!/bin/bash

echo "🧺 Olala Laundry Dashboard - Setup Script"
echo "=========================================="
echo ""

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js no está instalado"
    echo "Por favor instala Node.js desde: https://nodejs.org/"
    exit 1
fi

echo "✅ Node.js $(node -v) detectado"
echo ""

# Install dependencies
echo "📦 Instalando dependencias..."
npm install

if [ $? -ne 0 ]; then
    echo "❌ Error instalando dependencias"
    exit 1
fi

echo "✅ Dependencias instaladas"
echo ""

# Check for service_account.json
if [ ! -f "service_account.json" ]; then
    echo "⚠️  service_account.json no encontrado"
    echo ""
    echo "Por favor:"
    echo "1. Copia tu archivo service_account.json a esta carpeta"
    echo "2. Ejecuta este script de nuevo"
    echo ""
    exit 1
fi

echo "✅ service_account.json encontrado"
echo ""

# Create .env file if it doesn't exist
if [ ! -f ".env" ]; then
    echo "📝 Creando archivo .env..."
    cp .env.example .env
    echo "✅ Archivo .env creado"
    echo ""
fi

echo "✨ Setup completado!"
echo ""
echo "Para iniciar el servidor, ejecuta:"
echo "  npm start"
echo ""
echo "Luego abre tu navegador en:"
echo "  http://localhost:3000"
echo ""
