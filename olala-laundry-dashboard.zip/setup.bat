@echo off
echo 🧺 Olala Laundry Dashboard - Setup Script (Windows)
echo =================================================
echo.

REM Check if Node.js is installed
where node >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo ❌ Node.js no está instalado
    echo Por favor instala Node.js desde: https://nodejs.org/
    pause
    exit /b 1
)

for /f "tokens=*" %%i in ('node -v') do set NODE_VERSION=%%i
echo ✅ Node.js %NODE_VERSION% detectado
echo.

REM Install dependencies
echo 📦 Instalando dependencias...
call npm install

if %ERRORLEVEL% NEQ 0 (
    echo ❌ Error instalando dependencias
    pause
    exit /b 1
)

echo ✅ Dependencias instaladas
echo.

REM Check for service_account.json
if not exist "service_account.json" (
    echo ⚠️  service_account.json no encontrado
    echo.
    echo Por favor:
    echo 1. Copia tu archivo service_account.json a esta carpeta
    echo 2. Ejecuta este script de nuevo
    echo.
    pause
    exit /b 1
)

echo ✅ service_account.json encontrado
echo.

REM Create .env file if it doesn't exist
if not exist ".env" (
    echo 📝 Creando archivo .env...
    copy .env.example .env
    echo ✅ Archivo .env creado
    echo.
)

echo ✨ Setup completado!
echo.
echo Para iniciar el servidor, ejecuta:
echo   npm start
echo.
echo Luego abre tu navegador en:
echo   http://localhost:3000
echo.
pause
